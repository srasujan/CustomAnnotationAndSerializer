package com.example.demo.test2;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.node.IntNode;
import com.fasterxml.jackson.databind.ser.ContextualSerializer;
import org.springframework.beans.BeanUtils;

import java.io.IOException;

public class DoubleDeserializer extends StdDeserializer<Test2> {

    protected DoubleDeserializer(Class<Test2> vc) {
        super(vc);
    }

    public DoubleDeserializer() {
        this(null);
    }

    @Override
    public Test2 deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException {
        JsonNode node = jp.getCodec().readTree(jp);
        String newValue = node.get("value").asText();
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(node);
        Test2 test2 = objectMapper.readValue(json, Test2.class);
        test2.setValue(newValue + "gument");
        return test2;
    }
}
